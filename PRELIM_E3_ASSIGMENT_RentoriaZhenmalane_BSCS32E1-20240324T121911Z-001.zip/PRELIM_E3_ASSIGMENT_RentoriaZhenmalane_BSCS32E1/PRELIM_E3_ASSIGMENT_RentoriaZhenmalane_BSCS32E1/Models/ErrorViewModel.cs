namespace PRELIM_E3_ASSIGMENT_RentoriaZhenmalane_BSCS32E1.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
